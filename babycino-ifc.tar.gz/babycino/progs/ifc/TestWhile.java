class TestWhile {
    public static void main(String[] a){
	System.out.println(0);
    }
}

class Flow {

    public int l() {
        boolean high;
        int low;

        while (high)
            low = 1;
        
	return 0;
    }

}


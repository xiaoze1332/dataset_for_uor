class TestIf {
    public static void main(String[] a){
	System.out.println(0);
    }
}

class Flow {

    public int l() {
        int high;
        int low;

        if (high < 2)
            low = 1;
        else
            high = 1;
        
	return 0;
    }

}


class DirectSafe {
    public static void main(String[] a){
	System.out.println(new Flow().l(1));
    }
}

class Flow {

    public int l(int h){
	int h1;
	h1 = h + 1;
	return (1 * 2);
    }

}


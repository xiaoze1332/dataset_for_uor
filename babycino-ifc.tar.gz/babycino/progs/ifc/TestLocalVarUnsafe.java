class TestLocalVarUnsafe {
    public static void main(String[] a){
	System.out.println(0);
    }
}

class Flow {

    public int l() {
        int high;
	return high;
    }

}


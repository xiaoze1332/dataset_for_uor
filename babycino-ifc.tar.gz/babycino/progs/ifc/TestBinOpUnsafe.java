class TestBinOpUnsafe {
    public static void main(String[] a){
	System.out.println(0);
    }
}

class Flow {

    public boolean l() {
	int high;
	int low;
	return high < low;
    }

}


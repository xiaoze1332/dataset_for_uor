class TestTrueSafe {
    public static void main(String[] a){
	System.out.println(0);
    }
}

class Flow {

    public boolean l() {
	return true;
    }

}


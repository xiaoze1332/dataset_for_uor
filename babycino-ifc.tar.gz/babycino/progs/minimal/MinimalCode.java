class MinimalCode {
    public static void main(String[] args) {
        System.out.println(new Simple().f());
    }
}

class Simple {
    public int f() {
        return 1;
    }
}


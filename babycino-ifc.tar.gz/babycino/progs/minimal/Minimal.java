class Minimal {
    public static void main(String[] args) {
        {
        }
    }
}


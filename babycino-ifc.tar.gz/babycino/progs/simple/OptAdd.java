class OptAdd{
    public static void main(String[] a){
	System.out.println((1 + 2) * 3);
    }
}


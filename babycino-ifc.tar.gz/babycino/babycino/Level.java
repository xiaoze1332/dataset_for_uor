package babycino;

// A security level.
public enum Level {
    LOW,
    HIGH;

    // Least upper bound of two security levels.
    public static Level lub(Level l1, Level l2) {
        // TODO: Task 1.1
        return null;
    }

    // Greatest lower bound of two security levels.
    public static Level glb(Level l1, Level l2) {
        // TODO: Task 1.2
        return null;
    }

    // Less than or equal on security levels.
    public static boolean le(Level l1, Level l2) {
        return ((l1 == l2) || (l1 == Level.LOW));
    }

}


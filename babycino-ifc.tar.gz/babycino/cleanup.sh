#!/bin/bash

rm babycino/*.class
rm babycino/MiniJava*.java
rm babycino/MiniJava*.tokens

